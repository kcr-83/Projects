import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-change-detection-default',
  templateUrl: './change-detection-default.component.html',
  styleUrls: ['./change-detection-default.component.scss']
})
export class ChangeDetectionDefaultComponent {

  constructor() {}


}
