import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-change-detection-onpush',
  templateUrl: './change-detection-onpush.component.html',
  styleUrls: ['./change-detection-onpush.component.scss']
})
export class ChangeDetectionOnpushComponent {

  constructor() {}


}
