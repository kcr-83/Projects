import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-multi-outlet',
  templateUrl: './multi-outlet.component.html',
  styleUrls: ['./multi-outlet.component.scss']
})
export class MultiOutletComponent {

  constructor() {}

}
