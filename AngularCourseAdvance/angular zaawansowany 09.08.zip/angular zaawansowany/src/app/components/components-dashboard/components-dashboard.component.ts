import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-components-dashboard',
  templateUrl: './components-dashboard.component.html',
  styleUrls: ['./components-dashboard.component.scss']
})
export class ComponentsDashboardComponent {

  constructor() {}

}
