import { MultiplyPipe } from './multiply.pipe';

describe('MultiplyPipe', () => {
  it('create an instance', () => {
    const pipe = new MultiplyPipe();
    expect(pipe).toBeTruthy();
  });
});
