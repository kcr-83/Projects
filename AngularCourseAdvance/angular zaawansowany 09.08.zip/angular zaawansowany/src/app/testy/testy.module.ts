import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TestyRoutingModule } from './testy-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    TestyRoutingModule
  ]
})
export class TestyModule {}
