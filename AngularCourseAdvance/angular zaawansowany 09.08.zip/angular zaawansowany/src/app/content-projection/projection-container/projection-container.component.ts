import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-projection-container',
  templateUrl: './projection-container.component.html',
  styleUrls: ['./projection-container.component.scss']
})
export class ProjectionContainerComponent {

  constructor() {}

}
