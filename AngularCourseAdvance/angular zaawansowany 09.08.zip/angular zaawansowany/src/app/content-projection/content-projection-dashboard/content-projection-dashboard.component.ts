import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-content-projection-dashboard',
  templateUrl: './content-projection-dashboard.component.html',
  styleUrls: ['./content-projection-dashboard.component.scss']
})
export class ContentProjectionDashboardComponent {

  protected sentencesCount = 2
  constructor() {}

}
