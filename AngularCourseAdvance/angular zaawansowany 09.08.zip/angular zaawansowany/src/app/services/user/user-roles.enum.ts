export enum UserRole {
  'Guest' = 'guest',
  'Moderator' = 'moderator',
  'Admin' = 'admin',
}